﻿-- Kích hoạt extension UUID để sinh chuỗi khóa chính
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. BẢNG NGUỜI DÙNG (USERS)
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'SUSPENDED', 'CLOSED')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. BẢNG TÀI KHOẢN THANH TOÁN (ACCOUNTS)
CREATE TABLE accounts (
    account_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE RESTRICT,
    account_number VARCHAR(30) NOT NULL UNIQUE,
    balance NUMERIC(18, 4) NOT NULL DEFAULT 0.0000 CHECK (balance >= 0.0000), -- Ràng buộc không bao giờ âm
    currency VARCHAR(3) NOT NULL DEFAULT 'VND',
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'FROZEN', 'CLOSED')),
    version INT NOT NULL DEFAULT 1, -- Phục vụ Optimistic Locking
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 3. BẢNG ĐƠN VỊ CHẤP NHẬN THANH TOÁN (MERCHANTS)
CREATE TABLE merchants (
    merchant_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    account_id UUID NOT NULL REFERENCES accounts(account_id) ON DELETE RESTRICT,
    name VARCHAR(100) NOT NULL,
    api_key VARCHAR(64) NOT NULL UNIQUE,
    secret_key VARCHAR(128) NOT NULL, -- Dùng cho HMAC Signature
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. BẢNG GIAO DỊCH (TRANSACTIONS - APPEND ONLY)
CREATE TABLE transactions (
    transaction_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    idempotency_key VARCHAR(64) NOT NULL UNIQUE, -- Chốt chặn cuối chống duplicate request
    source_account_id UUID REFERENCES accounts(account_id),
    destination_account_id UUID REFERENCES accounts(account_id),
    amount NUMERIC(18, 4) NOT NULL CHECK (amount > 0.0000),
    fee NUMERIC(18, 4) NOT NULL DEFAULT 0.0000,
    currency VARCHAR(3) NOT NULL DEFAULT 'VND',
    type VARCHAR(30) NOT NULL CHECK (type IN ('DEPOSIT', 'WITHDRAW', 'TRANSFER', 'MERCHANT_PAYMENT')),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'SUCCESS', 'FAILED', 'REVERSED')),
    error_code VARCHAR(50),
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    -- Ràng buộc: Giao dịch chuyển tiền phải có tài khoản nguồn và đích khác nhau
    CONSTRAINT chk_different_accounts CHECK (source_account_id IS NULL OR destination_account_id IS NULL OR source_account_id <> destination_account_id)
);

-- 5. BẢNG NHẬT KÝ KIỂM TOÁN TÀI KHOẢN (ACCOUNT AUDIT LOGS)
CREATE TABLE account_audit_logs (
    audit_id BIGSERIAL PRIMARY KEY,
    account_id UUID NOT NULL REFERENCES accounts(account_id),
    transaction_id UUID NOT NULL REFERENCES transactions(transaction_id),
    action VARCHAR(20) NOT NULL CHECK (action IN ('CREDIT', 'DEBIT')), -- CREDIT: Cộng tiền, DEBIT: Trừ tiền
    balance_before NUMERIC(18, 4) NOT NULL,
    amount NUMERIC(18, 4) NOT NULL,
    balance_after NUMERIC(18, 4) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 🎯 TỐI ƯU HÓA INDEXES CHO HIGH-THROUGHPUT LOOKUPS
CREATE INDEX idx_accounts_user_id ON accounts(user_id);
CREATE INDEX idx_transactions_source_acc ON transactions(source_account_id);
CREATE INDEX idx_transactions_dest_acc ON transactions(destination_account_id);
CREATE INDEX idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX idx_audit_logs_account_id ON account_audit_logs(account_id);