﻿-- Clean up (nếu cần re-seed)
TRUNCATE users, accounts, merchants, transactions, account_audit_logs CASCADE;

-- 1. Thêm Users mẫu
INSERT INTO users (user_id, email, full_name) VALUES 
('11111111-1111-1111-1111-111111111111', 'alice@vpbank.demo', 'Alice Nguyen'),
('22222222-2222-2222-2222-222222222222', 'bob@vpbank.demo', 'Bob Tran');

-- 2. Thêm Accounts mẫu với số dư ban đầu
INSERT INTO accounts (account_id, user_id, account_number, balance, currency) VALUES 
('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', '11111111-1111-1111-1111-111111111111', '1000000001', 5000000.0000, 'VND'),
('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', '22222222-2222-2222-2222-222222222222', '1000000002', 2000000.0000, 'VND');

-- 3. Thêm Merchant mẫu
INSERT INTO merchants (merchant_id, account_id, name, api_key, secret_key) VALUES 
('33333333-3333-3333-3333-333333333333', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Shopee Store', 'merchant_key_shopee_01', 'super_secret_hmac_key_999');