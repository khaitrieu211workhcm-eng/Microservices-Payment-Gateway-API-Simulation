﻿import redis.asyncio as aioredis
from app.config import settings

# Khai báo Client Async Redis
redis_client: aioredis.Redis = aioredis.from_url(
    settings.REDIS_URL,
    decode_responses=True,
    max_connections=50,
    socket_timeout=5.0
)

async def init_redis_connection():
    """Kiểm tra kết nối tới Redis Server khi ứng dụng Startup."""
    try:
        await redis_client.ping()
        print(" [🟢 Redis] Kết nối Redis Server thành công!")
    except Exception as e:
        print(f" [🔴 Redis Error] Không thể kết nối tới Redis Server: {e}")

async def close_redis_connection():
    """Đóng kết nối an toàn khi ứng dụng Shutdown."""
    await redis_client.aclose()
    print(" [🔴 Redis] Đã đóng kết nối Redis.")