﻿import time
from typing import Annotated
from fastapi import APIRouter, Depends, Request, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas import TransferRequest, TransactionResponse
from app.services import PaymentService
from app.security import verify_hmac_signature
from app.event_bus import event_publisher
from app.database import get_db
from app.models import Merchant
from app.metrics import (
    PAYMENT_TRANSACTION_VOLUME_TOTAL,
    PAYMENT_TRANSACTIONS_TOTAL,
    PAYMENT_PROCESSING_LATENCY
)

router = APIRouter(prefix="/api/v1/merchants", tags=["Merchant Payment Gateway"])

@router.post(
    "/pay",
    response_model=TransactionResponse,
    status_code=status.HTTP_200_OK,
    summary="Thanh toán đơn hàng qua Merchant (HMAC Security & Async Event Bus)"
)
async def merchant_payment(
    request: Request,
    payload: TransferRequest,
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")],
    db: Annotated[AsyncSession, Depends(get_db)],  # Đã chuyển sang chuẩn Annotated
    merchant: Merchant = Depends(verify_hmac_signature)  # Xác thực HMAC-SHA256 Signature
):
    start_time = time.time()
    try:
        # 1. Thực hiện chuyển tiền Core Banking (Pessimistic Locking & ACID)
        transaction = await PaymentService.process_transfer(
            session=db,
            idempotency_key=idempotency_key,
            source_account_id=payload.source_account_id,
            destination_account_id=merchant.account_id,  # Chuyển trực tiếp vào tài khoản Merchant
            amount=payload.amount,
            description=f"Thanh toán đơn hàng qua Merchant: {merchant.name}"
        )

        # 2. Bắn Event "transaction.success" vào RabbitMQ để xử lý bất đồng bộ
        await event_publisher.publish_event(
            routing_key="transaction.success",
            message_data={
                "transaction_id": str(transaction.transaction_id),
                "merchant_id": str(merchant.merchant_id),
                "amount": transaction.amount,
                "status": transaction.status,
                "created_at": str(transaction.created_at)
            }
        )

        # 3. Ghi nhận Custom Metrics cho Prometheus & Grafana
        PAYMENT_TRANSACTION_VOLUME_TOTAL.labels(
            payment_type="MERCHANT_PAYMENT",
            currency=transaction.currency
        ).inc(float(transaction.amount))

        PAYMENT_TRANSACTIONS_TOTAL.labels(
            type="MERCHANT_PAYMENT",
            status="SUCCESS",
            error_code="NONE"
        ).inc()

        PAYMENT_PROCESSING_LATENCY.labels(
            payment_type="MERCHANT_PAYMENT"
        ).observe(time.time() - start_time)

        return transaction

    except HTTPException as exc:
        # Ghi nhận Metric giao dịch thất bại
        PAYMENT_TRANSACTIONS_TOTAL.labels(
            type="MERCHANT_PAYMENT",
            status="FAILED",
            error_code=str(exc.status_code)
        ).inc()
        raise exc