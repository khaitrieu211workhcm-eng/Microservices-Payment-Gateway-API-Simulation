﻿import json
import logging
import asyncio
from decimal import Decimal
import aio_pika
from app.config import settings

logger = logging.getLogger(__name__)


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super().default(obj)


class EventPublisher:
    def __init__(self):
        self.connection = None
        self.channel = None

    async def connect(self, retries: int = 5, delay: int = 3):
        """
        Khởi tạo kết nối tới RabbitMQ với cơ chế Retry tự động.
        """
        for attempt in range(1, retries + 1):
            try:
                logger.info(f"Đang kết nối tới RabbitMQ (Lần thử {attempt}/{retries})...")
                # Lấy URL kết nối động từ Settings (trỏ tới host rabbitmq trong Docker)
                self.connection = await aio_pika.connect_robust(settings.RABBITMQ_URL)
                self.channel = await self.connection.channel()
                
                # Khai báo Exchange loại Topic
                await self.channel.declare_exchange(
                    "payment_events", 
                    aio_pika.ExchangeType.TOPIC, 
                    durable=True
                )
                print(f" [🟢 RabbitMQ] Kết nối thành công tới RabbitMQ Server!")
                return
            except Exception as e:
                if attempt == retries:
                    print(f" [RabbitMQ Warning] Không thể kết nối RabbitMQ sau {retries} lần thử ({e}). Tạm thời bỏ qua Event Publishing.")
                    raise e
                print(f" [RabbitMQ Retry] Chưa kết nối được ({e}). Thử lại sau {delay} giây...")
                await asyncio.sleep(delay)

    async def close(self):
        """
        Đóng kết nối RabbitMQ an toàn khi Shutdown app.
        """
        if self.connection and not self.connection.is_closed:
            await self.connection.close()
            print(" [RabbitMQ] Đã đóng kết nối RabbitMQ thành công.")

    async def publish_event(self, routing_key: str, message_data: dict):
        """
        Publish message/event tới Exchange 'payment_events'.
        """
        if not self.channel or self.channel.is_closed:
            try:
                await self.connect(retries=3, delay=2)
            except Exception:
                logger.error("Không thể kết nối lại RabbitMQ. Bỏ qua gửi event.")
                return

        exchange = await self.channel.get_exchange("payment_events")
        message_body = json.dumps(message_data, cls=DecimalEncoder).encode('utf-8')

        await exchange.publish(
            aio_pika.Message(
                body=message_body,
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT  # Đảm bảo tin nhắn không mất khi RabbitMQ restart
            ),
            routing_key=routing_key
        )


event_publisher = EventPublisher()