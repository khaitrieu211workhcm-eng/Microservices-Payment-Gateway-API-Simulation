﻿import asyncio
import json
import uuid
import httpx

URL = "http://localhost:8000/api/v1/payments/transfer"

# Khai báo 2 tài khoản Alice (A) và Bob (B)
ACCOUNT_A = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
ACCOUNT_B = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"

# Giao dịch 1: Alice chuyển cho Bob (A -> B)
KEY_1 = f"TEST-DEADLOCK-A2B-{uuid.uuid4()}"
PAYLOAD_1 = {
    "source_account_id": ACCOUNT_A,
    "destination_account_id": ACCOUNT_B,
    "amount": 50000,
    "description": "Test Case 6 - Luồng 1: Alice chuyển Bob"
}

# Giao dịch 2: Bob chuyển cho Alice (B -> A)
KEY_2 = f"TEST-DEADLOCK-B2A-{uuid.uuid4()}"
PAYLOAD_2 = {
    "source_account_id": ACCOUNT_B,
    "destination_account_id": ACCOUNT_A,
    "amount": 30000,
    "description": "Test Case 6 - Luồng 2: Bob chuyển Alice"
}

async def send_transfer(thread_name: str, idempotency_key: str, payload: dict):
    headers = {
        "Content-Type": "application/json",
        "Idempotency-Key": idempotency_key
    }
    async with httpx.AsyncClient() as client:
        print(f"🚀 [{thread_name}] Bắt đầu gửi request chuyển tiền...")
        try:
            response = await client.post(URL, json=payload, headers=headers, timeout=10.0)
            print(f"📩 [{thread_name}] HTTP Status Code: {response.status_code}")
            try:
                body = response.json()
                print(f"📄 [{thread_name}] Response Body: {json.dumps(body, ensure_ascii=False, indent=2)}\n")
            except Exception:
                print(f"📄 [{thread_name}] Raw Body: {response.text}\n")
        except Exception as exc:
            print(f"❌ [{thread_name}] Lỗi kết nối HTTP: {exc}\n")

async def main():
    print("==================================================")
    print("🔥 KHỞI CHẠY KIỂM THỬ CHỐNG DEADLOCK (TEST CASE 6)")
    print(f"🔄 Luồng 1 (A -> B): Key {KEY_1}")
    print(f"🔄 Luồng 2 (B -> A): Key {KEY_2}")
    print("==================================================\n")

    # Bắn 2 request chuyển tiền chéo nhau CÙNG MỘT THỜI ĐIỂM
    await asyncio.gather(
        send_transfer("Luồng 1 (A -> B)", KEY_1, PAYLOAD_1),
        send_transfer("Luồng 2 (B -> A)", KEY_2, PAYLOAD_2)
    )

if __name__ == "__main__":
    asyncio.run(main())