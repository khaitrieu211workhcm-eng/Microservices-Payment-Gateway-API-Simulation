﻿import hmac
import hashlib
from typing import Annotated
from fastapi import Request, HTTPException, status, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Merchant
from app.database import get_db

async def verify_hmac_signature(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)] # Sử dụng Annotated để FastAPI không nhận diện nhầm Pydantic field
) -> Merchant:
    api_key = request.headers.get("X-API-Key")
    signature = request.headers.get("X-Signature")

    if not api_key or not signature:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Thiếu Header 'X-API-Key' hoặc 'X-Signature'."
        )

    stmt = select(Merchant).where(Merchant.api_key == api_key, Merchant.status == "ACTIVE")
    result = await db.execute(stmt)
    merchant = result.scalar_one_or_none()

    if not merchant:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API Key không hợp lệ hoặc Merchant đã bị khóa."
        )

    body_bytes = await request.body()
    expected_signature = hmac.new(
        key=merchant.secret_key.encode('utf-8'),
        msg=body_bytes,
        digestmod=hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(expected_signature.lower(), signature.lower()):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Chữ ký dữ liệu (X-Signature) không hợp lệ."
        )

    return merchant