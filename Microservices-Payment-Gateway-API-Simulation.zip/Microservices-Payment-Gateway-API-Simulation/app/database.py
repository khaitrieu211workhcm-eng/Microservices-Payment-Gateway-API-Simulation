﻿from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from app.config import settings

# Cấu hình Connection Pool cho PostgreSQL
engine = create_async_engine(
    settings.ASYNC_DATABASE_URL,
    echo=settings.DEBUG,
    pool_size=20,          # Số lượng kết nối mở sẵn duy trì thường trực
    max_overflow=10,       # Số lượng kết nối tối đa cho phép vượt ngưỡng khi quá tải
    pool_timeout=30,       # Thời gian chờ kết nối khả dụng trước khi báo lỗi
    pool_pre_ping=True     # Tự động kiểm tra trạng thái sống/chết của connection trước khi sử dụng
)

# Khởi tạo Async Session Factory
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False
)

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency cung cấp Async Session cho từng HTTP Request."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()