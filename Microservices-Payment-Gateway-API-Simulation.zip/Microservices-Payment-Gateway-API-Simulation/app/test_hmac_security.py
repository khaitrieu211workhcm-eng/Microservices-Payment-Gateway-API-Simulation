﻿import asyncio
import hmac
import hashlib
import json
import uuid
import httpx

URL = "http://localhost:8000/api/v1/merchants/pay"

# Thông số Merchant mẫu từ database
API_KEY = "merchant_api_key_demo"
SECRET_KEY = "merchant_secret_key_demo"

SOURCE_ACC = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
DEST_ACC = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"

def create_hmac_signature(secret_key: str, body_bytes: bytes) -> str:
    """Hàm tạo chữ ký HMAC-SHA256 từ Body Bytes"""
    return hmac.new(
        key=secret_key.encode('utf-8'),
        msg=body_bytes,
        digestmod=hashlib.sha256
    ).hexdigest()

async def run_hmac_tests():
    idempotency_key = f"TEST-HMAC-{uuid.uuid4()}"
    
    payload = {
        "source_account_id": SOURCE_ACC,
        "destination_account_id": DEST_ACC,
        "amount": 100000,
        "description": "Thanh toan don hang qua Merchant"
    }
    
    body_bytes_original = json.dumps(payload).encode('utf-8')
    valid_signature = create_hmac_signature(SECRET_KEY, body_bytes_original)

    async with httpx.AsyncClient() as client:
        print("==================================================")
        print("KHỞI CHẠY KIỂM THỬ BẢO MẬT HMAC (TEST CASE 8)")
        print("==================================================\n")

        # -------------------------------------------------------------
        # KỊCH BẢN A: CHỮ KÝ HỢP LỆ (Happy Path)
        # -------------------------------------------------------------
        print("1. Thử nghiệm Chữ ký HỢP LỆ (Valid Signature)...")
        headers_valid = {
            "Content-Type": "application/json",
            "Idempotency-Key": idempotency_key,
            "X-API-Key": API_KEY,
            "X-Signature": valid_signature
        }
        res_valid = await client.post(URL, content=body_bytes_original, headers=headers_valid)
        print(f"HTTP Status Code: {res_valid.status_code}")
        print(f"Response: {res_valid.json()}\n")

        # -------------------------------------------------------------
        # KỊCH BẢN B: CAN THIỆP DỮ LIỆU (Sửa amount từ 100k lên 500k)
        # -------------------------------------------------------------
        print("2. Thử nghiệm CỐ TÌNH SỬA BẢNG TIN DỮ LIỆU (Tampered Body)...")
        tampered_payload = payload.copy()
        tampered_payload["amount"] = 500000
        tampered_bytes = json.dumps(tampered_payload).encode('utf-8')

        headers_tampered = {
            "Content-Type": "application/json",
            "Idempotency-Key": f"TEST-HMAC-TAMPERED-{uuid.uuid4()}",
            "X-API-Key": API_KEY,
            "X-Signature": valid_signature
        }
        res_tampered = await client.post(URL, content=tampered_bytes, headers=headers_tampered)
        print(f"HTTP Status Code: {res_tampered.status_code}")
        print(f"Response: {res_tampered.json()}\n")

        # -------------------------------------------------------------
        # KỊCH BẢN C: GIẢ MẠO CHỮ KÝ
        # -------------------------------------------------------------
        print("3. Thử nghiệm CHỮ KÝ GIẢ MẠO (Fake Signature)...")
        headers_fake = {
            "Content-Type": "application/json",
            "Idempotency-Key": f"TEST-HMAC-FAKE-{uuid.uuid4()}",
            "X-API-Key": API_KEY,
            "X-Signature": "1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
        }
        res_fake = await client.post(URL, content=body_bytes_original, headers=headers_fake)
        print(f"HTTP Status Code: {res_fake.status_code}")
        print(f"Response: {res_fake.json()}\n")

if __name__ == "__main__":
    asyncio.run(run_hmac_tests())