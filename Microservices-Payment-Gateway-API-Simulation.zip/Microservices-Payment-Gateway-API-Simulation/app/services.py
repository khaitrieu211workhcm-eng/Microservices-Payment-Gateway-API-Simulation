﻿import uuid
from decimal import Decimal
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import HTTPException, status

from app.models import Account, Transaction, AccountAuditLog

class PaymentService:

    @staticmethod
    async def process_transfer(
        session: AsyncSession,
        idempotency_key: str,
        source_account_id: uuid.UUID,
        destination_account_id: uuid.UUID,
        amount: Decimal,
        description: str
    ) -> Transaction:
        
        if source_account_id == destination_account_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tài khoản nguồn và tài khoản đích không được trùng nhau."
            )

        if amount <= Decimal("0.0000"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Số tiền giao dịch phải lớn hơn 0."
            )

        # ------------------------------------------------------------------
        # BƯỚC 1: CHỐNG DEADLOCK BẰNG CÁCH SẮP XẾP UUID THEO THỨ TỰ THƯỜNG
        # ------------------------------------------------------------------
        first_lock_id, second_lock_id = sorted([source_account_id, destination_account_id])

        # ------------------------------------------------------------------
        # BƯỚC 2: KHÓA DÒNG TÀI KHOẢN VỚI SELECT ... FOR UPDATE
        # ------------------------------------------------------------------
        # Khóa tài khoản có ID nhỏ hơn trước
        stmt_first = select(Account).where(Account.account_id == first_lock_id).with_for_update()
        res_first = await session.execute(stmt_first)
        acc_first = res_first.scalar_one_or_none()

        # Khóa tài khoản có ID lớn hơn sau
        stmt_second = select(Account).where(Account.account_id == second_lock_id).with_for_update()
        res_second = await session.execute(stmt_second)
        acc_second = res_second.scalar_one_or_none()

        if not acc_first or not acc_second:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Một trong hai tài khoản không tồn tại trên hệ thống."
            )

        # Gán lại biến nguồn và đích
        source_acc = acc_first if acc_first.account_id == source_account_id else acc_second
        dest_acc = acc_first if acc_first.account_id == destination_account_id else acc_second

        # ------------------------------------------------------------------
        # BƯỚC 3: KIỂM TRA ĐIỀU KIỆN TÀI KHOẢN VÀ SỐ DƯ
        # ------------------------------------------------------------------
        if source_acc.status != "ACTIVE" or dest_acc.status != "ACTIVE":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tài khoản đang bị khóa hoặc không ở trạng thái hoạt động."
            )

        if source_acc.balance < amount:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Số dư không đủ. Số dư hiện tại: {source_acc.balance} VND."
            )

        # ------------------------------------------------------------------
        # BƯỚC 4: THỰC HIỆN TRỪ/CỘNG TIỀN VÀ CẬP NHẬT TRẠNG THÁI (ACID)
        # ------------------------------------------------------------------
        # Lưu lại số dư trước khi giao dịch
        src_balance_before = source_acc.balance
        dest_balance_before = dest_acc.balance

        # Cập nhật số dư trực tiếp
        source_acc.balance -= amount
        dest_acc.balance += amount
        source_acc.version += 1
        dest_acc.version += 1

        # 1. Tạo bản ghi Transaction (Tạo trạng thái SUCCESS)
        transaction = Transaction(
            transaction_id=uuid.uuid4(),
            idempotency_key=idempotency_key,
            source_account_id=source_account_id,
            destination_account_id=destination_account_id,
            amount=amount,
            fee=Decimal("0.0000"),
            currency="VND",
            type="TRANSFER",
            status="SUCCESS",
            description=description
        )
        session.add(transaction)
        await session.flush() # Flush để lấy transaction_id

        # 2. Tạo Audit Log ghi lại lịch sử tài khoản nguồn (DEBIT)
        src_audit = AccountAuditLog(
            account_id=source_acc.account_id,
            transaction_id=transaction.transaction_id,
            action="DEBIT",
            balance_before=src_balance_before,
            amount=amount,
            balance_after=source_acc.balance
        )
        
        # 3. Tạo Audit Log ghi lại lịch sử tài khoản đích (CREDIT)
        dest_audit = AccountAuditLog(
            account_id=dest_acc.account_id,
            transaction_id=transaction.transaction_id,
            action="CREDIT",
            balance_before=dest_balance_before,
            amount=amount,
            balance_after=dest_acc.balance
        )
        
        session.add_all([src_audit, dest_audit])

        # COMMIT toàn bộ Transaction vào PostgreSQL
        await session.commit()
        await session.refresh(transaction)

        return transaction