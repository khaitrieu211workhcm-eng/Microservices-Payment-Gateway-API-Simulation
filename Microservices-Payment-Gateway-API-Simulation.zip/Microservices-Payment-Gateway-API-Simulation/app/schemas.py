﻿import uuid
from decimal import Decimal
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from datetime import datetime

class TransferRequest(BaseModel):
    source_account_id: uuid.UUID
    destination_account_id: uuid.UUID
    amount: Decimal = Field(..., gt=0, description="Số tiền cần chuyển, phải lớn hơn 0")
    description: Optional[str] = "Chuyển tiền nhanh 24/7"

class TransactionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    transaction_id: uuid.UUID
    idempotency_key: str
    source_account_id: uuid.UUID
    destination_account_id: uuid.UUID
    amount: Decimal
    fee: Decimal
    currency: str
    type: str
    status: str
    description: Optional[str]
    created_at: datetime