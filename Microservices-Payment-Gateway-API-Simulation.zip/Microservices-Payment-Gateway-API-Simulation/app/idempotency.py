﻿import json
import logging
from decimal import Decimal
from typing import Callable
from fastapi import Request, Response, HTTPException, status
import redis.asyncio as aioredis
import redis.exceptions
from app.config import settings

logger = logging.getLogger(__name__)

# Sử dụng REDIS_URL động lấy trực tiếp từ settings
redis_client = aioredis.from_url(settings.REDIS_URL, decode_responses=True)

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        return super().default(obj)

async def check_idempotency_middleware(request: Request, call_next: Callable) -> Response:
    # Chỉ kiểm tra idempotency đối với các HTTP Methods làm thay đổi dữ liệu (POST, PUT, PATCH)
    if request.method not in ["POST", "PUT", "PATCH"]:
        return await call_next(request)

    idempotency_key = request.headers.get("Idempotency-Key")
    if not idempotency_key:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Header 'Idempotency-Key' là bắt buộc đối với giao dịch thanh toán."
        )

    redis_key = f"idempotency:{idempotency_key}"
    
    # 1. Thử khóa Key trạng thái IN_PROGRESS trong 30 giây (Atomic SETNX)
    try:
        is_set = await redis_client.set(redis_key, json.dumps({"status": "PROCESSING"}), nx=True, ex=30)

        if not is_set:
            # Nếu không set được key -> Key đã tồn tại trong Redis
            cached_data = await redis_client.get(redis_key)
            if cached_data:
                data = json.loads(cached_data)
                if data.get("status") == "PROCESSING":
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail="Giao dịch với Idempotency-Key này đang được xử lý. Vui lòng chờ."
                    )
                
                # Đã xử lý xong trước đó -> Trả về kết quả từ Cache ngay lập tức
                return Response(
                    content=json.dumps(data["response"]),
                    status_code=data["status_code"],
                    media_type="application/json",
                    headers={"X-Cache": "HIT-IDEMPOTENCY"}
                )
    except redis.exceptions.ConnectionError as err:
        # Nếu Redis mất kết nối, log cảnh báo và tiếp tục xử lý request (Bypass cache idempotency)
        logger.warning(f"Lỗi kết nối Redis trong Idempotency Middleware: {err}. Tiến hành bypass kiểm tra idempotency.")
        return await call_next(request)

    # 2. Key chưa từng tồn tại -> Cho phép đi tiếp vào Controller xử lý logic DB
    response = await call_next(request)

    # 3. Sau khi xử lý xong, lưu kết quả hoặc xóa key nếu lỗi
    try:
        if 200 <= response.status_code < 300:
            response_body = [chunk async for chunk in response.body_iterator]
            response.body_iterator = iterate_in_chunks(response_body)  # Re-populate stream
            
            body_content = json.loads(response_body[0].decode())
            cache_payload = {
                "status": "COMPLETED",
                "status_code": response.status_code,
                "response": body_content
            }
            await redis_client.set(redis_key, json.dumps(cache_payload, cls=DecimalEncoder), ex=86400)  # 24 Hours
        else:
            # Nếu giao dịch bị lỗi hệ thống, xóa key để Client có thể retry lại
            await redis_client.delete(redis_key)
    except redis.exceptions.ConnectionError as err:
        logger.warning(f"Không thể ghi kết quả cache vào Redis do lỗi kết nối: {err}")

    return response

async def iterate_in_chunks(chunks):
    for chunk in chunks:
        yield chunk