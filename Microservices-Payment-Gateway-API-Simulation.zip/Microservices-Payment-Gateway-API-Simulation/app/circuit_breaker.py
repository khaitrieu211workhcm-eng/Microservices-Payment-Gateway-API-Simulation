﻿import pybreaker
import httpx
from fastapi import HTTPException, status

# Khởi tạo Circuit Breaker: Ngắt kết nối nếu gặp 3 lỗi liên tiếp, thời gian chờ khôi phục (reset_timeout) là 20 giây
core_banking_breaker = pybreaker.CircuitBreaker(
    fail_max=3,
    reset_timeout=20,
    name="CoreBankingExternalService"
)

class ExternalCoreBankingService:

    @staticmethod
    @core_banking_breaker
    async def call_external_gateway(payload: dict):
        """
        Hàm bọc bởi Circuit Breaker mô phỏng gọi API sang Ngân hàng đối tác bên ngoài
        """
        async with httpx.AsyncClient(timeout=3.0) as client:
            try:
                # Giả lập URL của Partner Gateway
                response = await client.post("https://mock-partner-bank.com/api/v1/settle", json=payload)
                response.raise_for_status()
                return response.json()
            except (httpx.RequestError, httpx.HTTPStatusError) as exc:
                # Ném lỗi để Circuit Breaker đếm số lần thất bại (Failure Counter)
                raise exc

async def safe_call_core_banking(payload: dict):
    try:
        return await ExternalCoreBankingService.call_external_gateway(payload)
    except pybreaker.CircuitBreakerError:
        # Trạng thái Breaker đang OPEN (Ngắt mạch)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Hệ thống Cổng Ngân hàng đối tác tạm thời ngắt kết nối do sự cố mạng (Circuit Breaker OPEN). Vui lòng thử lại sau."
        )