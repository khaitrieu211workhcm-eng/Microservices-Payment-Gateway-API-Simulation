﻿from prometheus_client import Counter, Histogram, Gauge

# 1. Custom Metric: Đếm tổng số tiền đã giao dịch thành công (VNĐ)
PAYMENT_TRANSACTION_VOLUME_TOTAL = Counter(
    "payment_transaction_volume_total",
    "Tổng số tiền đã giao dịch thành công qua hệ thống (VND)",
    ["payment_type", "currency"]
)

# 2. Custom Metric: Đếm tổng số giao dịch phân loại theo Trạng thái & Mã lỗi
PAYMENT_TRANSACTIONS_TOTAL = Counter(
    "payment_transactions_total",
    "Tổng số lượng giao dịch tài chính",
    ["type", "status", "error_code"]
)

# 3. Custom Metric: Đo độ trễ xử lý DB Transaction & Lock (Giây)
PAYMENT_PROCESSING_LATENCY = Histogram(
    "payment_processing_latency_seconds",
    "Đo độ trễ thời gian xử lý giao dịch trong Core Engine",
    ["payment_type"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0)
)

# 4. Custom Metric: Theo dõi số lượng DB Lock đang giữ theo thời gian thực
ACTIVE_PAYMENT_LOCKS = Gauge(
    "active_payment_locks_count",
    "Số lượng giao dịch đang giữ Pessimistic Lock trong Database"
)