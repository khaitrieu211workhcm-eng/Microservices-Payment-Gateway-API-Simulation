﻿import time
from typing import Annotated
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, Request, Header, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from prometheus_fastapi_instrumentator import Instrumentator

from app.config import settings
from app.database import get_db, engine
from app.redis_client import init_redis_connection, close_redis_connection
from app.schemas import TransferRequest, TransactionResponse
from app.services import PaymentService
from app.idempotency import check_idempotency_middleware
from app.event_bus import event_publisher
from app.merchant_api import router as merchant_router
from app.metrics import (
    PAYMENT_TRANSACTION_VOLUME_TOTAL,
    PAYMENT_TRANSACTIONS_TOTAL,
    PAYMENT_PROCESSING_LATENCY
)

# ------------------------------------------------------------------
# LIFECYCLE MANAGEMENT (STARTUP & SHUTDOWN EVENTS)
# ------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    # --- Startup Actions ---
    try:
        await init_redis_connection()
    except Exception as e:
        print(f" [⚠️ Redis Warning] Chưa kết nối được Redis ({e}). Tạm thời bỏ qua Idempotency Cache.")

    try:
        # Tự động retry kết nối RabbitMQ 5 lần (mỗi lần cách nhau 3 giây)
        await event_publisher.connect(retries=5, delay=3)
    except Exception as e:
        pass  # Đã log thông báo trong hàm connect()

    print(f" [🚀 App Status] {settings.APP_NAME} đã sẵn sàng phục vụ trên cổng {settings.PORT}")

    yield

    # --- Shutdown Actions ---
    try:
        await close_redis_connection()
    except Exception:
        pass

    try:
        await event_publisher.close()
    except Exception:
        pass

    await engine.dispose()
    print(" [🛑 App Status] Đã dọn dẹp và ngắt toàn bộ kết nối hệ thống.")

# ------------------------------------------------------------------
# FASTAPI APP INITIALIZATION
# ------------------------------------------------------------------
app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    description="Mô phỏng Cổng thanh toán độ tin cậy cao chuẩn Ngân hàng (High-Throughput & Idempotent)",
    lifespan=lifespan
)

# ------------------------------------------------------------------
# PROMETHEUS INSTRUMENTATOR SETUP
# ------------------------------------------------------------------
instrumentator = Instrumentator(
    should_group_status_codes=False,
    should_ignore_untemplated=True,
    should_instrument_requests_inprogress=True,
    excluded_handlers=["/metrics", "/health", "/docs", "/openapi.json"]
)

# Kích hoạt Instrumentator và Expose endpoint /metrics chuẩn vị trí
instrumentator.instrument(app).expose(app, endpoint="/metrics")

# ------------------------------------------------------------------
# MIDDLEWARE REGISTRATION
# ------------------------------------------------------------------
@app.middleware("http")
async def custom_idempotency_middleware(request: Request, call_next):
    return await check_idempotency_middleware(request, call_next)

# ------------------------------------------------------------------
# ROUTER REGISTRATION
# ------------------------------------------------------------------
app.include_router(merchant_router)

# ------------------------------------------------------------------
# ENDPOINTS / ROUTES
# ------------------------------------------------------------------
@app.get("/health", tags=["System Health"])
async def health_check():
    return {"status": "UP", "app_name": settings.APP_NAME, "env": settings.ENV}


@app.post(
    "/api/v1/payments/transfer",
    response_model=TransactionResponse,
    status_code=status.HTTP_200_OK,
    tags=["Core Payment Engine"],
    summary="Thực hiện chuyển tiền 24/7 giữa 2 tài khoản (ACID, Pessimistic Locking & Idempotent)"
)
async def transfer_money(
    payload: TransferRequest,
    idempotency_key: Annotated[str, Header(alias="Idempotency-Key")],
    db: Annotated[AsyncSession, Depends(get_db)]
):
    start_time = time.time()
    try:
        # Thực hiện chuyển tiền qua Core Payment Service
        transaction = await PaymentService.process_transfer(
            session=db,
            idempotency_key=idempotency_key,
            source_account_id=payload.source_account_id,
            destination_account_id=payload.destination_account_id,
            amount=payload.amount,
 description=payload.description
        )

        # GHI NHẬN CUSTOM METRICS KHI GIAO DỊCH THÀNH CÔNG
        PAYMENT_TRANSACTION_VOLUME_TOTAL.labels(
            payment_type="TRANSFER",
            currency=transaction.currency
        ).inc(float(transaction.amount))

        PAYMENT_TRANSACTIONS_TOTAL.labels(
            type="TRANSFER",
            status="SUCCESS",
            error_code="NONE"
        ).inc()

        PAYMENT_PROCESSING_LATENCY.labels(
            payment_type="TRANSFER"
        ).observe(time.time() - start_time)

        return transaction

    except HTTPException as exc:
        # GHI NHẬN CUSTOM METRICS KHI GIAO DỊCH LỖI
        PAYMENT_TRANSACTIONS_TOTAL.labels(
            type="TRANSFER",
            status="FAILED",
            error_code=str(exc.status_code)
        ).inc()
        raise exc