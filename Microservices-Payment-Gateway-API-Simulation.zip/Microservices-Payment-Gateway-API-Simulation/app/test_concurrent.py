﻿import asyncio
import json
import uuid
import httpx

URL = "http://localhost:8000/api/v1/payments/transfer"

# TỰ ĐỘNG TẠO KEY MỚI MỖI LẦN CHẠY ĐỂ TRÁNH TRỤNG CACHE CŨ
IDEMPOTENCY_KEY = f"TEST-CONCURRENT-{uuid.uuid4()}"

HEADERS = {
    "Content-Type": "application/json",
    "Idempotency-Key": IDEMPOTENCY_KEY
}

PAYLOAD = {
    "source_account_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
    "destination_account_id": "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
    "amount": 100000,
    "description": "Test Case 5 - Request dong thoi"
}

async def send_request(request_id: int):
    async with httpx.AsyncClient() as client:
        print(f"[Request {request_id}] Đang gửi request...")
        try:
            response = await client.post(URL, json=PAYLOAD, headers=HEADERS, timeout=10.0)
            print(f"[Request {request_id}] HTTP Status Code: {response.status_code}")
            
            x_cache = response.headers.get("X-Cache", "NONE")
            print(f"[Request {request_id}] X-Cache Header: {x_cache}")

            try:
                body = response.json()
                print(f"[Request {request_id}] Body: {json.dumps(body, ensure_ascii=False, indent=2)}\n")
            except Exception:
                print(f"[Request {request_id}] Raw Body: {response.text}\n")

        except Exception as exc:
            print(f"❌ [Request {request_id}] Lỗi kết nối HTTP: {exc}\n")

async def main():
    print("==================================================")
    print("KHỞI CHẠY KIỂM THỬ ĐỒNG THỜI (TEST CASE 5)")
    print(f"Idempotency-Key: {IDEMPOTENCY_KEY}")
    print("==================================================\n")

    await asyncio.gather(
        send_request(1),
        send_request(2)
    )

if __name__ == "__main__":
    asyncio.run(main())