﻿import uuid
import json
from locust import HttpUser, task, between

# ID tài khoản mẫu khởi tạo từ seed.sql
SOURCE_ACC = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"  # Account Alice (Số dư: 5,000,000 VND)
DEST_ACC = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"    # Account Bob (Số dư: 2,000,000 VND)

class PaymentGatewayStressTest(HttpUser):
    wait_time = between(0.1, 0.5) # Giảm thời gian chờ giữa các request để tạo áp lực tải cao

    @task(3)
    def test_normal_transfer(self):
        """
        KỊCH BẢN 1: Chuyển tiền hợp lệ với Idempotency-Key mới liên tục (Max TPS Test)
        """
        idempotency_key = str(uuid.uuid4())
        headers = {
            "Content-Type": "application/json",
            "Idempotency-Key": idempotency_key
        }
        payload = {
            "source_account_id": SOURCE_ACC,
            "destination_account_id": DEST_ACC,
            "amount": "10000.0000",
            "description": "Stress Test - Transfer Normal"
        }
        self.client.post("/api/v1/payments/transfer", json=payload, headers=headers)

    @task(2)
    def test_idempotency_duplicate_requests(self):
        """
        KỊCH BẢN 2: Gửi 10 request trùng CÙNG 1 Idempotency-Key (Chống trừ tiền trùng)
        Kỳ vọng: Chỉ 1 request đầu vào DB, các request sau nhận Cache từ Redis.
        """
        shared_key = f"duplicate-test-key-{uuid.uuid4()}"
        headers = {
            "Content-Type": "application/json",
            "Idempotency-Key": shared_key
        }
        payload = {
            "source_account_id": SOURCE_ACC,
            "destination_account_id": DEST_ACC,
            "amount": "50000.0000",
            "description": "Stress Test - Duplicate Idempotency"
        }
        
        # Gửi request đầu tiên
        self.client.post("/api/v1/payments/transfer", json=payload, headers=headers)
        
        # Gửi ngay request thứ 2 trùng Key
        response = self.client.post("/api/v1/payments/transfer", json=payload, headers=headers)
        if response.headers.get("X-Cache") == "HIT-IDEMPOTENCY":
            response.failure("Chưa nhận đúng Header Cache Idempotency!") if response.status_code != 200 else None

    @task(1)
    def test_race_condition_overdraft(self):
        """
        KỊCH BẢN 3: Rút số tiền lớn liên tục để thử thách Pessimistic Locking (Chống âm số dư)
        """
        headers = {
            "Content-Type": "application/json",
            "Idempotency-Key": str(uuid.uuid4())
        }
        payload = {
            "source_account_id": SOURCE_ACC,
            "destination_account_id": DEST_ACC,
            "amount": "2000000.0000", # Rút 2 triệu mỗi lần
            "description": "Stress Test - Race Condition Overdraft"
        }
        # Khi hết tiền, API bắt buộc trả về 400 Bad Request
        with self.client.post("/api/v1/payments/transfer", json=payload, headers=headers, catch_response=True) as response:
            if response.status_code == 400 and "Số dư không đủ" in response.text:
                response.success() # Đánh dấu thành công vì ứng dụng bắt đúng lỗi số dư âm