﻿"""Initial financial schema

Revision ID: 0001
Revises: 
Create Date: 2026-10-06 14:35:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# Định danh phiên bản Alembic
revision: str = '0001'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. Kích hoạt Extension sinh UUID v4 định danh duy nhất toàn cầu
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp";')

    # 2. Bảng quản lý hồ sơ định danh khách hàng (CIF - Customer Information File)
    op.create_table(
        'users',
        # Mã CIF / Customer ID định danh duy nhất chủ thể
        sa.Column('user_id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        # Email đăng ký E-Banking (định danh tài khoản)
        sa.Column('email', sa.String(length=255), nullable=False),
        # Họ tên khách hàng theo giấy tờ định danh (CCCD/CMND)
        sa.Column('full_name', sa.String(length=100), nullable=False),
        # Trạng thái hồ sơ CIF: ACTIVE (Hoạt động), SUSPENDED (Tạm khóa), CLOSED (Đóng)
        sa.Column('status', sa.String(length=20), server_default='ACTIVE', nullable=False),
        # Thời điểm tạo hồ sơ và cập nhật thông tin
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        
        sa.PrimaryKeyConstraint('user_id'),
        sa.UniqueConstraint('email'),
        # Ràng buộc trạng thái CIF hợp lệ
        sa.CheckConstraint("status IN ('ACTIVE', 'SUSPENDED', 'CLOSED')", name='chk_users_status')
    )

    # 3. Bảng quản lý tài khoản thanh toán tiền gửi (Deposit Accounts)
    op.create_table(
        'accounts',
        # Mã định danh tài khoản nội bộ (Primary Key)
        sa.Column('account_id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        # Mã CIF chủ sở hữu tài khoản (FK -> users)
        sa.Column('user_id', postgresql.UUID(as_uuid=True), nullable=False),
        # Số tài khoản ngân hàng hiển thị
        sa.Column('account_number', sa.String(length=30), nullable=False),
        # Số dư khả dụng (Numeric 18,4 tránh lỗi làm tròn tiền tệ)
        sa.Column('balance', sa.Numeric(precision=18, scale=4), server_default='0.0000', nullable=False),
        # Mã loại tiền tệ theo chuẩn ISO 4217 (Mặc định: VND)
        sa.Column('currency', sa.String(length=3), server_default='VND', nullable=False),
        # Trạng thái tài khoản: ACTIVE (Hoạt động), FROZEN (Phong tỏa), CLOSED (Tất toán)
        sa.Column('status', sa.String(length=20), server_default='ACTIVE', nullable=False),
        # Phiên bản xử lý khóa lạc quan (Optimistic Locking) chống ghi đè đồng thời
        sa.Column('version', sa.Integer(), server_default='1', nullable=False),
        # Thời gian khởi tạo và biến động số dư gần nhất
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        
        # Chặn xóa khách hàng khi đang gắn liền với tài khoản
        sa.ForeignKeyConstraint(['user_id'], ['users.user_id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('account_id'),
        sa.UniqueConstraint('account_number'),
        # Ràng buộc nghiệp vụ: Chặn thấu chi trái phép (Số dư balance >= 0)
        sa.CheckConstraint('balance >= 0.0000', name='chk_account_balance_positive'),
        # Ràng buộc danh mục trạng thái tài khoản
        sa.CheckConstraint("status IN ('ACTIVE', 'FROZEN', 'CLOSED')", name='chk_account_status')
    )
    # Index tối ưu tra cứu danh sách tài khoản theo Mã CIF
    op.create_index('idx_accounts_user_id', 'accounts', ['user_id'])

    # 4. Bảng quản lý đơn vị chấp nhận thanh toán (Payment Gateway Merchant)
    op.create_table(
        'merchants',
        # Mã định danh đối tác Merchant
        sa.Column('merchant_id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        # Tài khoản ngân hàng thụ hưởng nhận tiền quyết toán (FK -> accounts)
        sa.Column('account_id', postgresql.UUID(as_uuid=True), nullable=False),
        # Tên doanh nghiệp/Thương hiệu Merchant
        sa.Column('name', sa.String(length=100), nullable=False),
        # API Key xác thực tích hợp
        sa.Column('api_key', sa.String(length=64), nullable=False),
        # Secret Key dùng để ký/kiểm tra chữ ký bảo mật HMAC-SHA256
        sa.Column('secret_key', sa.String(length=128), nullable=False),
        # Trạng thái kết nối: ACTIVE (Hoạt động), INACTIVE (Ngừng kết nối)
        sa.Column('status', sa.String(length=20), server_default='ACTIVE', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        
        sa.ForeignKeyConstraint(['account_id'], ['accounts.account_id'], ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('merchant_id'),
        sa.UniqueConstraint('api_key'),
        sa.CheckConstraint("status IN ('ACTIVE', 'INACTIVE')", name='chk_merchant_status')
    )

    # 5. Sổ lệnh giao dịch Core Banking (Transaction Ledger)
    op.create_table(
        'transactions',
        # Mã giao dịch duy nhất (Transaction Reference ID / Mã FT)
        sa.Column('transaction_id', postgresql.UUID(as_uuid=True), server_default=sa.text('uuid_generate_v4()'), nullable=False),
        # Idempotency Key bảo đảm giao dịch chỉ xử lý đúng 1 lần (Tránh duplicate payment)
        sa.Column('idempotency_key', sa.String(length=64), nullable=False),
        # Tài khoản trích nợ / Nguồn (NULL nếu là Nạp tiền DEPOSIT)
        sa.Column('source_account_id', postgresql.UUID(as_uuid=True), nullable=True),
        # Tài khoản ghi có / Đích (NULL nếu là Rút tiền WITHDRAW)
        sa.Column('destination_account_id', postgresql.UUID(as_uuid=True), nullable=True),
        # Giá trị giao dịch gốc
        sa.Column('amount', sa.Numeric(precision=18, scale=4), nullable=False),
        # Phí xử lý giao dịch
        sa.Column('fee', sa.Numeric(precision=18, scale=4), server_default='0.0000', nullable=False),
        # Loại tiền tệ giao dịch
        sa.Column('currency', sa.String(length=3), server_default='VND', nullable=False),
        # Loại hình: DEPOSIT (Nạp), WITHDRAW (Rút), TRANSFER (Chuyển khoản), MERCHANT_PAYMENT (Thanh toán đơn hàng)
        sa.Column('type', sa.String(length=30), nullable=False),
        # Trạng thái: PENDING (Đang xử lý), SUCCESS (Thành công), FAILED (Thất bại), REVERSED (Hoàn tiền)
        sa.Column('status', sa.String(length=20), server_default='PENDING', nullable=False),
        # Mã lỗi trả về từ Core Banking nếu thất bại
        sa.Column('error_code', sa.String(length=50), nullable=True),
        # Nội dung/Lời nhắn chuyển tiền
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        
        sa.ForeignKeyConstraint(['source_account_id'], ['accounts.account_id']),
        sa.ForeignKeyConstraint(['destination_account_id'], ['accounts.account_id']),
        sa.PrimaryKeyConstraint('transaction_id'),
        sa.UniqueConstraint('idempotency_key'),
        # Ràng buộc số tiền giao dịch phải lớn hơn 0
        sa.CheckConstraint('amount > 0.0000', name='chk_transaction_amount_positive'),
        sa.CheckConstraint("type IN ('DEPOSIT', 'WITHDRAW', 'TRANSFER', 'MERCHANT_PAYMENT')", name='chk_transaction_type'),
        sa.CheckConstraint("status IN ('PENDING', 'SUCCESS', 'FAILED', 'REVERSED')", name='chk_transaction_status'),
        # Chặn tự chuyển tiền cho chính mình (Source và Destination không được trùng nhau)
        sa.CheckConstraint("source_account_id IS NULL OR destination_account_id IS NULL OR source_account_id <> destination_account_id", name='chk_different_accounts')
    )
    # Index tối ưu truy vấn tra cứu lịch sử giao dịch theo Tài khoản nguồn, Tài khoản đích và Thời gian
    op.create_index('idx_transactions_source_acc', 'transactions', ['source_account_id'])
    op.create_index('idx_transactions_dest_acc', 'transactions', ['destination_account_id'])
    op.create_index('idx_transactions_created_at', 'transactions', ['created_at'])

    # 6. Sổ nhật ký đối soát & kiểm toán tài chính kép (Double-Entry Audit Trail)
    op.create_table(
        'account_audit_logs',
        # Mã nhật ký tự tăng BigInt phục vụ lưu trữ dung lượng lớn
        sa.Column('audit_id', sa.BigInteger(), autoincrement=True, nullable=False),
        # Tài khoản chịu biến động số dư
        sa.Column('account_id', postgresql.UUID(as_uuid=True), nullable=False),
        # Mã giao dịch gốc tham chiếu (FK -> transactions)
        sa.Column('transaction_id', postgresql.UUID(as_uuid=True), nullable=False),
        # Bút toán kế toán: DEBIT (Ghi Nợ / Trừ tiền), CREDIT (Ghi Có / Cộng tiền)
        sa.Column('action', sa.String(length=20), nullable=False),
        # Số dư tài khoản NGAY TRƯỚC khi hạch toán
        sa.Column('balance_before', sa.Numeric(precision=18, scale=4), nullable=False),
        # Giá trị biến động thực tế của bút toán
        sa.Column('amount', sa.Numeric(precision=18, scale=4), nullable=False),
        # Số dư tài khoản NGAY SAU khi hạch toán (balance_after = balance_before ± amount)
        sa.Column('balance_after', sa.Numeric(precision=18, scale=4), nullable=False),
        # Thời điểm ghi sổ kế toán (Bất biến - Immutable)
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        
        sa.ForeignKeyConstraint(['account_id'], ['accounts.account_id']),
        sa.ForeignKeyConstraint(['transaction_id'], ['transactions.transaction_id']),
        sa.PrimaryKeyConstraint('audit_id'),
        sa.CheckConstraint("action IN ('CREDIT', 'DEBIT')", name='chk_audit_action')
    )
    # Index tối ưu in sao kê biến động tài khoản
    op.create_index('idx_audit_logs_account_id', 'account_audit_logs', ['account_id'])


def downgrade() -> None:
    # Hoàn tác Schema theo thứ tự ngược lại để đảm bảo không vi phạm ràng buộc khóa ngoại
    op.drop_table('account_audit_logs')
    op.drop_table('transactions')
    op.drop_table('merchants')
    op.drop_table('accounts')
    op.drop_table('users')