﻿import asyncio
import json
import logging
import aio_pika
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main():
    retries = 5
    delay = 3
    connection = None

    # 1. Retry kết nối tới RabbitMQ với cơ chế tự động thử lại
    for attempt in range(1, retries + 1):
        try:
            logger.info(f"Notification Worker đang kết nối RabbitMQ (Lần {attempt}/{retries})...")
            connection = await aio_pika.connect_robust(settings.RABBITMQ_URL)
            break
        except Exception as e:
            if attempt == retries:
                logger.error(f"Worker không thể kết nối RabbitMQ sau {retries} lần thử: {e}")
                return
            logger.warning(f"Chưa kết nối được RabbitMQ ({e}). Thử lại sau {delay} giây...")
            await asyncio.sleep(delay)

    async with connection:
        channel = await connection.channel()

        # 2. Khai báo Exchange & Queue
        exchange = await channel.declare_exchange(
            "payment_events", 
            aio_pika.ExchangeType.TOPIC, 
            durable=True
        )
        queue = await channel.declare_queue(
            "notification_queue", 
            durable=True
        )

        # 3. Bind Queue với Routing Key (Nhận tất cả các event dạng transaction.*)
        await queue.bind(exchange, routing_key="transaction.#")

        print(" [🟢 Notification Worker] Đã tạo 'notification_queue', Bind thành công và đang lắng nghe sự kiện từ RabbitMQ.")

        # 4. Lắng nghe và xử lý tin nhắn
        async with queue.iterator() as queue_iter:
            async for message in queue_iter:
                async with message.process():
                    event_data = json.loads(message.body.decode())
                    print(" [📩 Notification Service] Nhận Event Giao Dịch Thành Công:")
                    print(f"     - Transaction ID: {event_data.get('transaction_id')}")
                    print(f"     - Số tiền: {event_data.get('amount')} VND")
                    print("     - Trạng thái: Đã gửi Email & SMS thông báo biến động số dư thành công!")


if __name__ == "__main__":
    asyncio.run(main())